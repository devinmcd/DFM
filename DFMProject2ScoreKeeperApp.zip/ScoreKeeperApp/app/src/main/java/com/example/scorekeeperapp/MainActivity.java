package com.example.scorekeeperapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int teamOneScore = 0;
    int teamTwoScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Team One
    public void displayTeamOneScore(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_one_score);
        scoreView.setText(String.valueOf(score));
    }

    public void sixPointsTeamOne(View v) {
        teamOneScore = teamOneScore + 6;
        displayTeamOneScore(teamOneScore);
    }

    public void threePointsTeamOne(View v) {
        teamOneScore = teamOneScore + 3;
        displayTeamOneScore(teamOneScore);
    }

    public void twoPointsTeamOne(View v) {
        teamOneScore = teamOneScore + 2;
        displayTeamOneScore(teamOneScore);
    }

    public void onePointTeamOne(View v) {
        teamOneScore = teamOneScore + 1;
        displayTeamOneScore(teamOneScore);
    }

    //Team Two
    public void displayTeamTwoScore(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_two_score);
        scoreView.setText(String.valueOf(score));
    }

    public void sixPointsTeamTwo(View v) {
        teamTwoScore = teamTwoScore + 6;
        displayTeamTwoScore(teamTwoScore);
    }

    public void threePointsTeamTwo(View v) {
        teamTwoScore = teamTwoScore + 3;
        displayTeamTwoScore(teamTwoScore);
    }

    public void twoPointsTeamTwo(View v) {
        teamTwoScore = teamTwoScore + 2;
        displayTeamTwoScore(teamTwoScore);
    }

    public void onePointTeamTwo(View v) {
        teamTwoScore = teamTwoScore + 1;
        displayTeamTwoScore(teamTwoScore);
    }

    //Reset Button
    public void resetScore(View v) {
        teamOneScore = 0;
        teamTwoScore = 0;
        displayTeamOneScore(teamOneScore);
        displayTeamTwoScore(teamTwoScore);
    }

}
