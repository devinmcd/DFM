package com.example.dfmproject3quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the Get Results button is clicked
     */

    public void getResults(View view) {
        // Create variable when the correct answer(s) is selected for question one
        CheckBox questionOneCorrectOne = (CheckBox) findViewById(R.id.question_one_correct_one);
        boolean correctAnswerOneOne = questionOneCorrectOne.isChecked();

        CheckBox questionOneCorrectTwo = (CheckBox) findViewById(R.id.question_one_correct_two);
        boolean correctAnswerOneTwo = questionOneCorrectTwo.isChecked();

        // Create variable when the correct answer(s) is selected for question two
        RadioButton questionTwoCorrect = (RadioButton) findViewById(R.id.question_two_correct);
        boolean correctAnswerTwo = questionTwoCorrect.isChecked();

        // Create variable when the correct answer(s) is selected for question three
        EditText questionThreeCorrect = (EditText) findViewById(R.id.question_three_correct);
        String correctAnswerThree = questionThreeCorrect.getText().toString();

        // Create variable when the correct answer(s) is selected for question four
        RadioButton questionFourCorrect = (RadioButton) findViewById(R.id.question_four_correct);
        boolean correctAnswerFour = questionFourCorrect.isChecked();

        // Create variable when the correct answer(s) is selected for question five
        RadioButton questionFiveCorrect = (RadioButton) findViewById(R.id.question_five_correct);
        boolean correctAnswerFive = questionFiveCorrect.isChecked();

        // Calculates the total score once all answers are accounted for
        int totalScore = calculateScore(correctAnswerOneOne, correctAnswerOneTwo, correctAnswerTwo, correctAnswerThree, correctAnswerFour, correctAnswerFive);
        Toast.makeText(this, "You scored " + totalScore + "/5", Toast.LENGTH_SHORT).show();

    }

    /**
     * Calculates the total score
     *
     * @param correctAnswerOneOne correct answer for question one
     * @param correctAnswerOneTwo correct answer for question one
     * @param correctAnswerTwo    correct answer for question two
     * @param correctAnswerThree  correct answer for question three
     * @param correctAnswerFour   correct answer for question four
     * @param correctAnswerFive   correct answer for question five
     * @return score
     */

    public int calculateScore(boolean correctAnswerOneOne, boolean correctAnswerOneTwo, boolean correctAnswerTwo, String correctAnswerThree, boolean correctAnswerFour, boolean correctAnswerFive) {
        int baseScore = 0;
        if (correctAnswerOneOne && correctAnswerOneTwo) {
            baseScore += 1;
        } else {
            baseScore += 0;
        }
        if (correctAnswerTwo) {
            baseScore += 1;
        } else {
            baseScore += 0;
        }
        if (correctAnswerThree.equalsIgnoreCase("Coit Tower")) {
            baseScore += 1;
        } else {
            baseScore += 0;
        }
        if (correctAnswerFour) {
            baseScore += 1;
        } else {
            baseScore += 0;
        }
        if (correctAnswerFive) {
            baseScore += 1;
        } else {
            baseScore += 0;
        }
        return baseScore;
    }

}