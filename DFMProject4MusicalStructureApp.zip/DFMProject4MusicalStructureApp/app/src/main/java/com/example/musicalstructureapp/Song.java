/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.musicalstructureapp;

/**
 * {@link Song} represents a song by an artist in the user's music library.
 */
public class Song {

    // Name of artist
    private String mArtistName;

    // Song title
    private String mSong;

    /**
     * Create a new Song object.
     *
     * @param artistName is the input string for the artist in the library.
     * @param song is the input string for the title of the song.
     */
    public Song(String artistName, String song) {
        mArtistName = artistName;
        mSong = song;
    }

    // Create a method to get the song name.
    public String getSong() {
        return mSong;
    }

    // Create a method to get the artist name.
    public String getArtistName() {
        return mArtistName;
    }


}